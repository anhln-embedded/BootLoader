#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parsing_srec.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/
int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL)
    {
        perror("Error opening file");
        return EXIT_FAILURE;
    }

    char line[MAX_LINE_LENGTH];
    uint32_t lineCount = 1;

    /** 
     * Read each line from the file and check its format.
     */
    while (fgets(line, sizeof(line), file) != NULL)
    {
        printf("Line %d: ", lineCount);
        ErrorCode_t errorCode = SrecReadLine(line);
        
        switch (errorCode)
        {
        case SREC_ERROR_NOERR:
            printf("TRUE format\n");
            break;
        case SREC_ERROR_CHECKSUM:
            printf("FALSE format\n");
            printf("Checksum error\n");
            break;
        case SREC_ERROR_REDUNDANT:
            printf("FALSE format\n");
            printf("Redundant data\n");
            break;
        case SREC_ERROR_SYNTAX:
            printf("FALSE format\n");
            printf("Syntax error\n");
            break;
        case SREC_ERROR_NOT_AVAILABLE_S4:
            printf("FALSE format\n");
            printf("S4 record not available\n");
            break;
        default:
            break;
        }
        lineCount++;
    }

    fclose(file);
    return EXIT_SUCCESS;
}



